from nltk.tag import pos_tag
import nltk
nltk.download('all')
import time
import datetime

import sys
import random
from textblob import TextBlob

now=datetime.datetime.now()

def polarity(sen):
    sentence=TextBlob(sen)
    
    p=sentence.sentiment.polarity
    return p

def subjectivity(sen):
    sentence=TextBlob(sen)
    s=sentence.sentiment.subjectivity
    return s
def check(sen):
    if(polarity(sen)<0 and subjectivity(sen)>=0.5):
        print ("Hey..you need to calm down..I just asked your name")
        print ("Come back when you are calm.. Byeee")
        sys.exit()
print("Welcome Morgan State University Student. It is now the hour " + str (now.hour)+ ".")
sen=input()

        

a=["Hey there. I couldn't recognize you. You are...??",
   "Hello there. May I know your name?",
   "Hello, What is your name?",
   "Hello",
   "How are you doing today?",
   "How are classes today?"
   "Are your grades looking good?"]
print(random.choice(a))
sen=input()
check(sen)
    
tagged_sent = pos_tag(sen.split())
name=[word for word,pos in tagged_sent if pos=='NNP']
print(" ".join(str(word) for word in name)+ "Thats really cool" )
flag=input()
if (polarity(flag)<0.2):
    print("What is your name?")
    name=input()
    print(name + " ..Gotcha.!! ")
print("All right. Now what's your gender.Male or female?")
gender=input()
gender=gender.upper()
if(gender != "MALE" and gender !="FEMALE"):
          print("One word please.. Male or female?")
          gender=input()    

check(gender)
a=["Great. Let's talk.",
   "Awesome. So let's get started "
   "Ohkk...So let's start talking"]
print(random.choice(a))
time.sleep(3)
print("What classes did you take today?")
sen=input()
print("Oh wow.. That must be really hard for you uhn? Anyways, How is it?")
sen=input()
if(polarity(sen)>=0.7):
          print("I knew it would be great..Gotta keep those grades up")
if(polarity(sen)>=0.5 and polarity(sen)<=0.7):
          print("Hmmm...it is quite good according to you. Anyway..you have to keep those grades up.")
if(polarity(sen)>=0 and polarity(sen) <=0.4):
          print("So it was a average according to you.. Now, You got my attention buddy")
if(polarity(sen)<0 and polarity(sen)>=-0.5):
          print("Oh..so it was bad for you today?")
if (polarity(sen)<-0.5):
          print("Oh No...Was it that bad? I hope it gets better next time.")

print("Have you eaten yet? Its past " +str(now.hour))
sen=input()
if(polarity(sen)>0.5):
    
    print("Good. I haven't either. Go get some food and rest then we can taalk later, Byee!!")
else:
    print("Good. First go get some rest then we can talk. Talk to you later, Byee!!")
